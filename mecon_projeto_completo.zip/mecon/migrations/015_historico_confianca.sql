-- MecOn - Migração 015: histórico de confiança da oficina
-- Registra QUANDO a oficina foi verificada (não só SE está verificada),
-- para poder exibir "verificada há X meses". Junto com contagens de
-- agendamentos concluídos e avaliações verificadas (já calculáveis a
-- partir de tabelas existentes), forma o bloco de confiança exibido na
-- página pública da oficina — ver backend/oficinas/get_oficina.php.

ALTER TABLE oficinas
    ADD COLUMN `verificada_em` timestamp NULL DEFAULT NULL AFTER `verificada`;
