-- MecOn - Migração 024: ordem de serviço digital
-- Liga em um só documento o que antes estava espalhado: o agendamento
-- aceito, o diagnóstico, o responsável, as etapas de execução, as peças
-- (itens_os), a mão de obra, o desconto e o fechamento. Uma OS por
-- agendamento (UNIQUE). Ao CONCLUIR a OS, o agendamento é concluído e o
-- histórico do cliente recebe valores, km e peças automaticamente — a
-- oficina digita uma vez só (ver backend/ordens_servico/concluir_os.php).
--
-- Etapas: aberta -> em_execucao <-> aguardando_peca -> pronta -> entregue.
-- "entregue" só é atingida pelo fechamento (concluir_os.php); as demais
-- podem ser alternadas livremente enquanto a OS está em andamento.
-- Valor total da OS = soma(quantidade x valor_unitario dos itens)
--                     + valor_mao_obra - desconto  (calculado, não armazenado).

CREATE TABLE `ordens_servico` (
  `id_os` int NOT NULL AUTO_INCREMENT,
  `id_agendamento` int NOT NULL,
  `id_oficina` int NOT NULL,
  `responsavel` varchar(100) DEFAULT NULL,
  `km_entrada` int DEFAULT NULL,
  `etapa` enum('aberta','em_execucao','aguardando_peca','pronta','entregue') NOT NULL DEFAULT 'aberta',
  `diagnostico` text,
  `observacoes` varchar(1000) DEFAULT NULL,
  `valor_mao_obra` decimal(10,2) DEFAULT NULL,
  `desconto` decimal(10,2) DEFAULT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `concluida_em` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_os`),
  UNIQUE KEY `os_por_agendamento` (`id_agendamento`),
  KEY `ordens_servico_ibfk_2` (`id_oficina`),
  CONSTRAINT `ordens_servico_ibfk_1` FOREIGN KEY (`id_agendamento`) REFERENCES `agendamentos` (`id_agendamento`) ON DELETE CASCADE,
  CONSTRAINT `ordens_servico_ibfk_2` FOREIGN KEY (`id_oficina`) REFERENCES `oficinas` (`id_oficina`) ON DELETE CASCADE,
  CONSTRAINT `chk_os_valores` CHECK (
    (`valor_mao_obra` IS NULL OR `valor_mao_obra` >= 0)
    AND (`desconto` IS NULL OR `desconto` >= 0)
    AND (`km_entrada` IS NULL OR `km_entrada` >= 0)
  )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `itens_os` (
  `id_item` int NOT NULL AUTO_INCREMENT,
  `id_os` int NOT NULL,
  `nome` varchar(150) NOT NULL,
  `quantidade` decimal(8,2) NOT NULL DEFAULT 1.00,
  `valor_unitario` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_item`),
  KEY `itens_os_ibfk_1` (`id_os`),
  CONSTRAINT `itens_os_ibfk_1` FOREIGN KEY (`id_os`) REFERENCES `ordens_servico` (`id_os`) ON DELETE CASCADE,
  CONSTRAINT `chk_item_os_quantidade` CHECK (`quantidade` > 0),
  CONSTRAINT `chk_item_os_valor` CHECK (`valor_unitario` IS NULL OR `valor_unitario` >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
