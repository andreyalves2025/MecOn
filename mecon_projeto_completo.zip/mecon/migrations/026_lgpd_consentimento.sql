-- MecOn - Migração 026: LGPD (Lei 13.709/2018)
-- Registra o aceite dos Termos de Uso e da Política de Privacidade (data e
-- versão do documento aceito) no cadastro do usuário. Contas anteriores a
-- esta migração ficam com NULL e o sistema pede o aceite no próximo login
-- (ver frontend/js/auth.js). A exportação e a exclusão da conta pelo próprio
-- titular são feitas por backend/usuarios/exportar_meus_dados.php e
-- backend/usuarios/excluir_minha_conta.php.

ALTER TABLE `usuarios`
  ADD COLUMN `termos_aceitos_em` timestamp NULL DEFAULT NULL AFTER `email_verificado`,
  ADD COLUMN `termos_versao` varchar(20) DEFAULT NULL AFTER `termos_aceitos_em`;

-- Exclusões de conta feitas pelo próprio titular ficam registradas SEM dados
-- pessoais (só o id e a data), para fins de prestação de contas.
ALTER TABLE `log_auditoria`
  MODIFY COLUMN `tipo_ator` enum('admin','usuario') NOT NULL DEFAULT 'admin';
