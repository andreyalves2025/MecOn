-- MecOn - Migração 017: controle de quilometragem
-- `veiculos.km_atual` guarda a quilometragem mais recente informada pelo
-- usuário (atualizada manualmente ou automaticamente ao registrar um
-- serviço com km informada — ver create_historico.php/update_historico.php).
-- `historico_manutencoes.km_servico` guarda a km do veículo NAQUELE
-- momento específico, permitindo reconstruir a evolução da quilometragem
-- ao longo do tempo (não só o valor mais recente). Ambos os campos são
-- opcionais: o usuário pode não informar km, e isso não deve bloquear o
-- cadastro de veículo/histórico.

ALTER TABLE veiculos
    ADD COLUMN `km_atual` int NULL AFTER `placa`;

ALTER TABLE historico_manutencoes
    ADD COLUMN `km_servico` int NULL AFTER `data_servico`;
