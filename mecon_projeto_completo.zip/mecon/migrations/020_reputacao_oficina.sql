-- MecOn - Migração 020: sistema de reputação da oficina
-- Para medir o tempo de resposta e distinguir "cancelado antes da oficina
-- responder" de "cancelado depois de aceito", é preciso guardar QUANDO a
-- oficina respondeu o agendamento. Não dá para usar `atualizado_em`: ele
-- muda a cada alteração de status (aceito -> concluído, cancelamento...).
--
-- respondido_em é preenchido por responder_agendamento.php (aceitar ou
-- recusar). Agendamentos antigos (anteriores a esta migração) ficam com
-- NULL de propósito — não há como reconstruir o momento real da resposta,
-- e um valor estimado distorceria a média. Eles seguem contando nas taxas
-- baseadas em status, só ficam de fora do tempo médio de resposta.

ALTER TABLE agendamentos
    ADD COLUMN `respondido_em` timestamp NULL DEFAULT NULL AFTER `resposta_oficina`;
