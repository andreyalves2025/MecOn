-- MecOn - Migração 006: selo de oficina verificada
-- Selo dado pelo admin após checar documentação/existência real da oficina,
-- reduzindo o risco de perfis falsos na plataforma. Não afeta nenhuma
-- regra de negócio (busca, preço, avaliação) — é só um indicador de
-- confiança exibido ao usuário.

ALTER TABLE oficinas
    ADD COLUMN `verificada` tinyint(1) NOT NULL DEFAULT 0 AFTER `descricao`;
