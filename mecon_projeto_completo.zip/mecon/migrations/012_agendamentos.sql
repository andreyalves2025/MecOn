-- MecOn - Migração 012: agendamento de serviço
-- Usuário solicita um horário direto pela plataforma; a oficina aceita ou
-- recusa. Quando a oficina marca como concluído, um registro de histórico
-- de manutenção é criado automaticamente para o usuário (ver
-- backend/agendamentos/concluir_agendamento.php) — assim o histórico do
-- usuário fica em dia sem trabalho manual dele.

CREATE TABLE `agendamentos` (
  `id_agendamento` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `id_oficina` int NOT NULL,
  `id_servico` int NOT NULL,
  `id_veiculo` int NOT NULL,
  `data_hora_solicitada` datetime NOT NULL,
  `mensagem_usuario` varchar(500) DEFAULT NULL,
  `status` enum('pendente','aceito','recusado','cancelado','concluido') NOT NULL DEFAULT 'pendente',
  `resposta_oficina` varchar(500) DEFAULT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_agendamento`),
  KEY `agendamentos_ibfk_1` (`id_usuario`),
  KEY `agendamentos_ibfk_2` (`id_oficina`),
  KEY `agendamentos_ibfk_3` (`id_servico`),
  KEY `agendamentos_ibfk_4` (`id_veiculo`),
  CONSTRAINT `agendamentos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `agendamentos_ibfk_2` FOREIGN KEY (`id_oficina`) REFERENCES `oficinas` (`id_oficina`) ON DELETE CASCADE,
  CONSTRAINT `agendamentos_ibfk_3` FOREIGN KEY (`id_servico`) REFERENCES `servicos` (`id_servico`) ON DELETE CASCADE,
  CONSTRAINT `agendamentos_ibfk_4` FOREIGN KEY (`id_veiculo`) REFERENCES `veiculos` (`id_veiculo`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
