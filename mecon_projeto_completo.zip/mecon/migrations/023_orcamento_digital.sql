-- MecOn - Migração 023: orçamento digital
-- Fluxo: o cliente descreve o problema (com fotos/vídeos) -> envia o pedido
-- a até 3 oficinas -> cada oficina responde com um orçamento -> o cliente
-- compara, aprova um e solicita o agendamento.
--
-- pedidos_orcamento : o problema do cliente (um pedido, vários orçamentos)
-- orcamentos        : a resposta de CADA oficina ao pedido (UNIQUE por par)
-- anexos_pedido     : fotos/vídeos do pedido. O arquivo em disco usa um nome
--                     aleatório (nome_arquivo); o nome original só aparece
--                     na tela. Os arquivos só saem do servidor por um
--                     endpoint que confere permissão (ver
--                     backend/orcamentos/baixar_anexo.php).
-- agendamentos.id_orcamento: liga o agendamento ao orçamento aprovado.
--
-- Status do orçamento: pendente (aguardando a oficina) -> respondido
-- (oficina enviou valores) -> aprovado | nao_escolhido (cliente aprovou
-- outro do mesmo pedido). Também: recusado (oficina declinou) e cancelado
-- (cliente cancelou o pedido).

CREATE TABLE `pedidos_orcamento` (
  `id_pedido` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `id_veiculo` int NOT NULL,
  `id_servico` int DEFAULT NULL,
  `descricao` text NOT NULL,
  `status` enum('aberto','aprovado','cancelado') NOT NULL DEFAULT 'aberto',
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pedido`),
  KEY `pedidos_orcamento_ibfk_1` (`id_usuario`),
  KEY `pedidos_orcamento_ibfk_2` (`id_veiculo`),
  KEY `pedidos_orcamento_ibfk_3` (`id_servico`),
  CONSTRAINT `pedidos_orcamento_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `pedidos_orcamento_ibfk_2` FOREIGN KEY (`id_veiculo`) REFERENCES `veiculos` (`id_veiculo`) ON DELETE CASCADE,
  CONSTRAINT `pedidos_orcamento_ibfk_3` FOREIGN KEY (`id_servico`) REFERENCES `servicos` (`id_servico`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `orcamentos` (
  `id_orcamento` int NOT NULL AUTO_INCREMENT,
  `id_pedido` int NOT NULL,
  `id_oficina` int NOT NULL,
  `status` enum('pendente','respondido','aprovado','nao_escolhido','recusado','cancelado') NOT NULL DEFAULT 'pendente',
  `valor_total` decimal(10,2) DEFAULT NULL,
  `valor_pecas` decimal(10,2) DEFAULT NULL,
  `valor_mao_obra` decimal(10,2) DEFAULT NULL,
  `prazo_dias` int DEFAULT NULL,
  `validade_ate` date DEFAULT NULL,
  `detalhes` varchar(1000) DEFAULT NULL,
  `respondido_em` timestamp NULL DEFAULT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_orcamento`),
  UNIQUE KEY `orcamento_por_oficina` (`id_pedido`, `id_oficina`),
  KEY `orcamentos_ibfk_2` (`id_oficina`),
  CONSTRAINT `orcamentos_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos_orcamento` (`id_pedido`) ON DELETE CASCADE,
  CONSTRAINT `orcamentos_ibfk_2` FOREIGN KEY (`id_oficina`) REFERENCES `oficinas` (`id_oficina`) ON DELETE CASCADE,
  CONSTRAINT `chk_orcamento_valores` CHECK (
    (`valor_total` IS NULL OR `valor_total` >= 0)
    AND (`valor_pecas` IS NULL OR `valor_pecas` >= 0)
    AND (`valor_mao_obra` IS NULL OR `valor_mao_obra` >= 0)
    AND (`prazo_dias` IS NULL OR `prazo_dias` >= 0)
  )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `anexos_pedido` (
  `id_anexo` int NOT NULL AUTO_INCREMENT,
  `id_pedido` int NOT NULL,
  `nome_original` varchar(255) NOT NULL,
  `nome_arquivo` varchar(64) NOT NULL,
  `tipo_mime` varchar(100) NOT NULL,
  `tamanho_bytes` int NOT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_anexo`),
  UNIQUE KEY `anexo_nome_arquivo` (`nome_arquivo`),
  KEY `anexos_pedido_ibfk_1` (`id_pedido`),
  CONSTRAINT `anexos_pedido_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos_orcamento` (`id_pedido`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

ALTER TABLE agendamentos
    ADD COLUMN `id_orcamento` int NULL AFTER `id_veiculo`,
    ADD CONSTRAINT `agendamentos_ibfk_5` FOREIGN KEY (`id_orcamento`) REFERENCES `orcamentos` (`id_orcamento`) ON DELETE SET NULL;
