-- MecOn - Migração 009: verificação de e-mail no cadastro
-- Reduz contas com e-mail inválido/de terceiros, que poderiam ser usadas
-- para deixar avaliações falsas. Usuário criado com email_verificado = 0;
-- ao clicar no link enviado por email (token de uso único, expira em 24h),
-- o backend marca como verificado. Ações sensíveis (avaliar oficina) só
-- são liberadas depois disso — ver backend/config/session_check.php
-- (exigirEmailVerificado) e backend/avaliacoes/create_review.php.

ALTER TABLE usuarios
    ADD COLUMN `email_verificado` tinyint(1) NOT NULL DEFAULT 0 AFTER `senha_hash`;

CREATE TABLE `tokens_verificacao_email` (
  `token` char(64) NOT NULL,
  `id_usuario` int NOT NULL,
  `expira_em` timestamp NOT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`token`),
  KEY `tokens_verificacao_email_ibfk_1` (`id_usuario`),
  CONSTRAINT `tokens_verificacao_email_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
