-- MecOn - Migração 003: preço por serviço, não mais média da oficina
-- Contexto: `oficinas.preco_medio` era um valor único por oficina, mas na
-- prática cada serviço que a oficina oferece tem seu próprio preço (troca
-- de óleo custa diferente de alinhamento, por exemplo). O preço passa a
-- viver em `oficina_servico`, por combinação oficina+serviço; a "média"
-- exibida ao usuário passa a ser calculada a partir daí, não mais
-- armazenada.

-- PASSO 1: adiciona a coluna, ainda opcional
ALTER TABLE oficina_servico
    ADD COLUMN `preco` decimal(10,2) NULL AFTER `id_servico`;

-- PASSO 2: preenche com o preco_medio que a oficina já tinha, como melhor
-- aproximação disponível a partir do dado legado (o admin/oficina deve
-- revisar e ajustar os valores reais depois pela tela de perfil).
UPDATE oficina_servico os
JOIN oficinas o ON o.id_oficina = os.id_oficina
SET os.preco = o.preco_medio
WHERE os.preco IS NULL;

-- PASSO 3: linhas órfãs sem preço (não deveria haver, mas por segurança)
UPDATE oficina_servico SET preco = 0 WHERE preco IS NULL;

-- PASSO 4: torna a coluna obrigatória e não-negativa
ALTER TABLE oficina_servico
    MODIFY `preco` decimal(10,2) NOT NULL;
ALTER TABLE oficina_servico
    ADD CONSTRAINT `chk_preco_servico` CHECK ((`preco` >= 0));

-- PASSO 5: remove a coluna obsoleta de oficinas (o valor agora é calculado
-- em tempo de consulta a partir de oficina_servico.preco)
ALTER TABLE oficinas
    DROP COLUMN `preco_medio`;
