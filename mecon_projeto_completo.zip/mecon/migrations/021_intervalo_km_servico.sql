-- MecOn - Migração 021: lembretes inteligentes (tempo + quilometragem)
-- Além do intervalo em meses (migração 010), cada serviço do catálogo
-- passa a poder ter um intervalo em quilômetros (ex: troca de óleo a cada
-- 10.000 km OU 6 meses, o que vier primeiro). O lembrete dispara pelo
-- critério que for atingido primeiro — ver
-- backend/historico/lembretes_manutencao.php. Ambos os intervalos são
-- opcionais e independentes; um serviço pode ter só um deles.

ALTER TABLE servicos
    ADD COLUMN `intervalo_recomendado_km` int NULL AFTER `intervalo_recomendado_meses`;
