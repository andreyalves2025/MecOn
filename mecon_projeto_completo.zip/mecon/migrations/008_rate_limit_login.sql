-- MecOn - Migração 008: rate limiting no login
-- Bloqueia tentativas de força bruta por e-mail: após N tentativas
-- inválidas seguidas, o e-mail fica temporariamente bloqueado, mesmo que
-- a senha certa seja tentada em seguida (só desbloqueia pelo tempo, ou por
-- um login bem-sucedido ser tentado depois do bloqueio expirar).
-- Não é por IP: o objetivo aqui é proteger a CONTA sendo atacada, que é o
-- risco mais direto (proteção por IP teria pouco efeito contra um invasor
-- distribuído e adicionaria complexidade sem ganho claro para o escopo
-- atual do projeto).

CREATE TABLE `tentativas_login` (
  `email` varchar(100) NOT NULL,
  `tentativas` int NOT NULL DEFAULT 1,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bloqueado_ate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
