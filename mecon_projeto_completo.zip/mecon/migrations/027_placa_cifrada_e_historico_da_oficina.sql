-- MecOn - Migração 027: placa cifrada + registros da oficina sobrevivem à exclusão da conta
--
-- 1) veiculos.placa passa a guardar a placa CIFRADA (AES-256-GCM, ver
--    backend/config/placa.php), por isso a coluna é ampliada. Depois desta
--    migração rode:  php backend/tools/cifrar_placas.php  (cifra o que já existe).
-- 2) agendamentos ganha placa_snapshot (cópia cifrada da placa no momento do
--    agendamento) e id_usuario/id_veiculo passam a aceitar NULL com
--    ON DELETE SET NULL: quando o cliente exclui a conta (ou um veículo), o
--    agendamento e a ordem de serviço PERMANECEM para a oficina, sem nome nem
--    e-mail do cliente ("Cliente removido"). Só os dados pessoais saem.

ALTER TABLE `veiculos` MODIFY COLUMN `placa` varchar(255) NOT NULL;

ALTER TABLE `agendamentos`
  ADD COLUMN `placa_snapshot` varchar(255) NULL AFTER `id_veiculo`;

UPDATE `agendamentos` a JOIN `veiculos` v ON v.id_veiculo = a.id_veiculo
   SET a.placa_snapshot = v.placa;

ALTER TABLE `agendamentos`
  DROP FOREIGN KEY `agendamentos_ibfk_1`,
  DROP FOREIGN KEY `agendamentos_ibfk_4`;
ALTER TABLE `agendamentos`
  MODIFY COLUMN `id_usuario` int NULL,
  MODIFY COLUMN `id_veiculo` int NULL;
ALTER TABLE `agendamentos`
  ADD CONSTRAINT `agendamentos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE SET NULL,
  ADD CONSTRAINT `agendamentos_ibfk_4` FOREIGN KEY (`id_veiculo`) REFERENCES `veiculos` (`id_veiculo`) ON DELETE SET NULL;
