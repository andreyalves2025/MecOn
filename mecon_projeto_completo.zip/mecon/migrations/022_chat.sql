-- MecOn - Migração 022: chat entre cliente e oficina
-- Canal interno para tirar dúvidas antes de agendar. Uma conversa por par
-- (usuário, oficina) — UNIQUE garante que não se criem conversas
-- duplicadas. Só o usuário inicia a conversa (a oficina responde), para
-- que oficinas não possam enviar mensagens não solicitadas.
--
-- Sem WebSocket: as telas consultam o servidor periodicamente (polling).
-- `lida_em` marca quando o DESTINATÁRIO abriu a mensagem; mensagens
-- não lidas de um lado = mensagens do outro remetente com lida_em NULL.
-- Apagar o usuário ou a oficina apaga a conversa e as mensagens (CASCADE).

CREATE TABLE `conversas` (
  `id_conversa` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `id_oficina` int NOT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ultima_mensagem_em` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_conversa`),
  UNIQUE KEY `conversa_unica` (`id_usuario`, `id_oficina`),
  KEY `conversas_ibfk_2` (`id_oficina`),
  CONSTRAINT `conversas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `conversas_ibfk_2` FOREIGN KEY (`id_oficina`) REFERENCES `oficinas` (`id_oficina`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `mensagens` (
  `id_mensagem` int NOT NULL AUTO_INCREMENT,
  `id_conversa` int NOT NULL,
  `remetente` enum('usuario','oficina') NOT NULL,
  `texto` varchar(2000) NOT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `lida_em` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_mensagem`),
  KEY `mensagens_conversa_ordem` (`id_conversa`, `id_mensagem`),
  CONSTRAINT `mensagens_ibfk_1` FOREIGN KEY (`id_conversa`) REFERENCES `conversas` (`id_conversa`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
