-- MecOn - Migração 002: soft delete no catálogo de serviços
-- Contexto: `oficina_servico` e `historico_manutencoes` referenciam
-- `servicos` com ON DELETE CASCADE. Um DELETE direto num serviço em uso
-- apagaria em cascata vínculos de oficinas e histórico de manutenções já
-- realizadas (perda de dado real). Por isso, serviços em uso são apenas
-- desativados (ativo = 0); só um serviço nunca usado pode ser removido
-- de verdade (ver backend/servicos/delete_servico.php).

ALTER TABLE servicos
    ADD COLUMN `ativo` tinyint(1) NOT NULL DEFAULT 1 AFTER `nome`;
