-- MecOn - Migração 013: log de auditoria
-- Registra quem fez o quê e quando em ações administrativas sensíveis
-- (excluir usuário/oficina/avaliação, verificar oficina, resolver
-- denúncia). Não guarda o "antes/depois" completo dos dados (fora do
-- escopo atual) — é um rastro de auditoria básico: ator, ação, entidade
-- afetada e um resumo em texto.

CREATE TABLE `log_auditoria` (
  `id_log` int NOT NULL AUTO_INCREMENT,
  `tipo_ator` enum('admin') NOT NULL DEFAULT 'admin',
  `id_ator` int NOT NULL,
  `acao` varchar(100) NOT NULL,
  `entidade` varchar(50) NOT NULL,
  `id_entidade` int DEFAULT NULL,
  `detalhes` varchar(500) DEFAULT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `log_auditoria_criado_em` (`criado_em`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
