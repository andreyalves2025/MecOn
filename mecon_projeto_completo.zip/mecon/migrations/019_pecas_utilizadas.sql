-- MecOn - Migração 019: cadastro de peças utilizadas
-- Detalha QUAIS peças foram usadas em cada manutenção do histórico (nome,
-- quantidade e valor unitário opcional) — complementa o valor_pecas
-- agregado da migração 018. Pertencem a um registro de histórico: se o
-- registro for apagado, as peças vão junto (ON DELETE CASCADE).
-- Se o usuário/oficina informar os valores unitários e não informar
-- valor_pecas, o backend calcula valor_pecas pela soma (ver
-- backend/config/pecas.php).

CREATE TABLE `pecas_utilizadas` (
  `id_peca` int NOT NULL AUTO_INCREMENT,
  `id_historico` int NOT NULL,
  `nome` varchar(150) NOT NULL,
  `quantidade` decimal(8,2) NOT NULL DEFAULT 1.00,
  `valor_unitario` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_peca`),
  KEY `pecas_utilizadas_ibfk_1` (`id_historico`),
  CONSTRAINT `pecas_utilizadas_ibfk_1` FOREIGN KEY (`id_historico`) REFERENCES `historico_manutencoes` (`id_historico`) ON DELETE CASCADE,
  CONSTRAINT `chk_peca_quantidade` CHECK (`quantidade` > 0),
  CONSTRAINT `chk_peca_valor` CHECK (`valor_unitario` IS NULL OR `valor_unitario` >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
