-- MecOn - Migração 007: promoções/ofertas das oficinas
-- Oficina divulga uma oferta temporária (ex: "10% de desconto em revisão").
-- "id_servico" é opcional (promoção pode ser geral, não ligada a um
-- serviço específico); se o serviço referenciado for excluído de verdade
-- (caso raro, só permitido quando nunca usado — ver delete_servico.php),
-- a promoção não é apagada, só perde a referência (ON DELETE SET NULL).

CREATE TABLE `promocoes` (
  `id_promocao` int NOT NULL AUTO_INCREMENT,
  `id_oficina` int NOT NULL,
  `id_servico` int DEFAULT NULL,
  `titulo` varchar(150) NOT NULL,
  `descricao` text,
  `data_inicio` date NOT NULL,
  `data_fim` date NOT NULL,
  `data_criacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_promocao`),
  KEY `promocoes_ibfk_1` (`id_oficina`),
  KEY `promocoes_ibfk_2` (`id_servico`),
  CONSTRAINT `promocoes_ibfk_1` FOREIGN KEY (`id_oficina`) REFERENCES `oficinas` (`id_oficina`) ON DELETE CASCADE,
  CONSTRAINT `promocoes_ibfk_2` FOREIGN KEY (`id_servico`) REFERENCES `servicos` (`id_servico`) ON DELETE SET NULL,
  CONSTRAINT `chk_periodo_promocao` CHECK ((`data_fim` >= `data_inicio`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
