-- MecOn - Migração 014: avaliação verificada por serviço realizado
-- Quando a avaliação nasce de um agendamento concluído pela própria
-- plataforma, ela ganha o selo "serviço confirmado pelo MecOn" — mais
-- forte que uma avaliação comum, porque comprova que o serviço realmente
-- aconteceu (não é só a palavra do avaliador). id_agendamento é opcional:
-- avaliações "soltas" (sem agendamento prévio pela plataforma) continuam
-- permitidas, só não ganham o selo.
-- UNIQUE em id_agendamento: um agendamento só pode gerar uma avaliação
-- verificada (evita inflar a nota com múltiplas avaliações "verificadas"
-- do mesmo serviço). NULL não conta para a UNIQUE (MySQL permite
-- múltiplos NULLs), então avaliações sem agendamento não são afetadas.

ALTER TABLE avaliacoes
    ADD COLUMN `id_agendamento` int NULL AFTER `id_oficina`,
    ADD CONSTRAINT `avaliacoes_ibfk_3` FOREIGN KEY (`id_agendamento`) REFERENCES `agendamentos` (`id_agendamento`) ON DELETE SET NULL,
    ADD UNIQUE KEY `avaliacao_por_agendamento` (`id_agendamento`);
