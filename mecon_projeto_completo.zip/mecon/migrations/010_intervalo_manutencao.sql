-- MecOn - Migração 010: intervalo recomendado de manutenção por serviço
-- Permite ao admin marcar, por tipo de serviço, de quantos em quantos
-- meses ele costuma precisar ser refeito (ex: troca de óleo a cada 6
-- meses). Usado para calcular lembretes de manutenção preventiva a partir
-- do histórico do usuário (ver backend/historico/lembretes_manutencao.php).
-- NULL = serviço sem periodicidade recomendada (não gera lembrete).

ALTER TABLE servicos
    ADD COLUMN `intervalo_recomendado_meses` int NULL AFTER `ativo`;
