-- MecOn - Migração 016: histórico de alterações detalhado
-- Evolui o log_auditoria (que só registrava QUE uma ação aconteceu) para
-- também registrar O QUÊ mudou, campo a campo: valor anterior e valor
-- novo. Uma linha de log_auditoria pode ter 0, 1 ou várias linhas de
-- detalhe (0 para ações sem alteração de campos, como "descartar
-- denúncia"; várias para uma exclusão, que registra o valor "anterior"
-- de cada coluna do registro apagado, com valor_novo NULL).

CREATE TABLE `log_auditoria_detalhe` (
  `id_detalhe` int NOT NULL AUTO_INCREMENT,
  `id_log` int NOT NULL,
  `campo` varchar(100) NOT NULL,
  `valor_anterior` text,
  `valor_novo` text,
  PRIMARY KEY (`id_detalhe`),
  KEY `log_auditoria_detalhe_ibfk_1` (`id_log`),
  CONSTRAINT `log_auditoria_detalhe_ibfk_1` FOREIGN KEY (`id_log`) REFERENCES `log_auditoria` (`id_log`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
