-- MecOn - Migração 028: avaliações sobrevivem à exclusão da conta, de forma anônima
-- Ao excluir a conta, a avaliação (nota, comentário e resposta da oficina) permanece
-- e passa a aparecer como "Cliente removido"; só o vínculo com a pessoa é desfeito.
ALTER TABLE `avaliacoes` DROP FOREIGN KEY `avaliacoes_ibfk_1`;
ALTER TABLE `avaliacoes` MODIFY COLUMN `id_usuario` int NULL;
ALTER TABLE `avaliacoes` ADD CONSTRAINT `avaliacoes_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE SET NULL;
