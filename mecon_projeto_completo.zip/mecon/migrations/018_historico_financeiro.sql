-- MecOn - Migração 018: histórico financeiro
-- Transforma o histórico de manutenção em um "livro digital do veículo":
-- além de quando/onde/qual serviço (e a km, ver migração 017), passa a
-- registrar quanto foi pago. valor_pecas e valor_mao_obra são um
-- detalhamento opcional do valor_total (que é o que de fato foi pago).
-- Sem constraint de igualdade entre eles: descontos, taxas e arredondamentos
-- fazem o total real divergir da soma das partes. O QUE foi de peça (itens
-- individuais) fica para o cadastro de peças, em migração própria.
--
-- agendamentos.valor_total: valor final informado pela OFICINA ao concluir
-- o serviço (dado confiável do lado da oficina). É copiado para o histórico
-- do cliente na conclusão e servirá de base para os relatórios financeiros
-- da oficina (que não devem usar valores digitados à mão pelo cliente).

ALTER TABLE historico_manutencoes
    ADD COLUMN `valor_total` decimal(10,2) NULL AFTER `km_servico`,
    ADD COLUMN `valor_pecas` decimal(10,2) NULL AFTER `valor_total`,
    ADD COLUMN `valor_mao_obra` decimal(10,2) NULL AFTER `valor_pecas`,
    ADD CONSTRAINT `chk_historico_valores` CHECK (
        (`valor_total` IS NULL OR `valor_total` >= 0)
        AND (`valor_pecas` IS NULL OR `valor_pecas` >= 0)
        AND (`valor_mao_obra` IS NULL OR `valor_mao_obra` >= 0)
    );

ALTER TABLE agendamentos
    ADD COLUMN `valor_total` decimal(10,2) NULL AFTER `resposta_oficina`,
    ADD CONSTRAINT `chk_agendamento_valor` CHECK (`valor_total` IS NULL OR `valor_total` >= 0);
