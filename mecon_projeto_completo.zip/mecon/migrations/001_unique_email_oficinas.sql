-- MecOn - Migração 001: garantir e-mail único por oficina
-- Contexto: `oficinas.email` funciona como credencial de login (junto com
-- senha_hash), mas até aqui não havia constraint de banco impedindo duas
-- oficinas com o mesmo e-mail — só havia checagem manual no PHP
-- (create_oficina.php / update_perfil_oficina.php), vulnerável a condição
-- de corrida (duas requisições simultâneas podem passar na checagem antes
-- de qualquer uma commitar).

-- PASSO 1: rodar antes de aplicar a constraint, para detectar duplicatas
-- já existentes na base atual. Se retornar linhas, resolva-as manualmente
-- (ex.: renomear/mesclar cadastros) antes de continuar.
SELECT email, COUNT(*) AS total
FROM oficinas
GROUP BY email
HAVING COUNT(*) > 1;

-- PASSO 2: aplicar a constraint (só rodar se o SELECT acima não retornou linhas)
ALTER TABLE oficinas
    ADD UNIQUE KEY `email` (`email`);
