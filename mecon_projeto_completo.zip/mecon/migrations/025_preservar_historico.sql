-- MecOn - Migração 025: preservar o histórico quando uma oficina deixa a plataforma
--
-- PROBLEMA: historico_manutencoes (e agendamentos/ordens_servico) apontavam
-- para a oficina com ON DELETE CASCADE. Excluir uma oficina apagava o
-- histórico de manutenção dos CLIENTES, que pertence ao veículo e ao dono dele.
--
-- CORREÇÃO:
--  1) oficinas ganha exclusão LÓGICA (ativa / desativada_em). O botão
--     "Excluir" do administrador passa a DESATIVAR a oficina: ela some das
--     buscas, não recebe novos pedidos e não faz login, mas o histórico dos
--     clientes continua intacto (com o nome da oficina).
--  2) As chaves estrangeiras que representam histórico passam de CASCADE para
--     RESTRICT: o banco recusa a exclusão física de uma oficina (ou de um
--     serviço) que já tenha histórico, agendamento ou OS. O histórico só é
--     removido quando o VEÍCULO ou a CONTA do cliente é excluído (ON DELETE
--     CASCADE em veiculos/usuarios continua), que é o direito de eliminação
--     da LGPD.

ALTER TABLE `oficinas`
  ADD COLUMN `ativa` tinyint(1) NOT NULL DEFAULT 1 AFTER `verificada_em`,
  ADD COLUMN `desativada_em` timestamp NULL DEFAULT NULL AFTER `ativa`;

ALTER TABLE `historico_manutencoes`
  DROP FOREIGN KEY `historico_manutencoes_ibfk_2`,
  DROP FOREIGN KEY `historico_manutencoes_ibfk_3`;
ALTER TABLE `historico_manutencoes`
  ADD CONSTRAINT `historico_manutencoes_ibfk_2` FOREIGN KEY (`id_oficina`) REFERENCES `oficinas` (`id_oficina`) ON DELETE RESTRICT,
  ADD CONSTRAINT `historico_manutencoes_ibfk_3` FOREIGN KEY (`id_servico`) REFERENCES `servicos` (`id_servico`) ON DELETE RESTRICT;

ALTER TABLE `agendamentos`
  DROP FOREIGN KEY `agendamentos_ibfk_2`,
  DROP FOREIGN KEY `agendamentos_ibfk_3`;
ALTER TABLE `agendamentos`
  ADD CONSTRAINT `agendamentos_ibfk_2` FOREIGN KEY (`id_oficina`) REFERENCES `oficinas` (`id_oficina`) ON DELETE RESTRICT,
  ADD CONSTRAINT `agendamentos_ibfk_3` FOREIGN KEY (`id_servico`) REFERENCES `servicos` (`id_servico`) ON DELETE RESTRICT;

ALTER TABLE `ordens_servico`
  DROP FOREIGN KEY `ordens_servico_ibfk_2`;
ALTER TABLE `ordens_servico`
  ADD CONSTRAINT `ordens_servico_ibfk_2` FOREIGN KEY (`id_oficina`) REFERENCES `oficinas` (`id_oficina`) ON DELETE RESTRICT;
