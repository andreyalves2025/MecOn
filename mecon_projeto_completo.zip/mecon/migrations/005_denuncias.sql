-- MecOn - Migração 005: denúncia de avaliação abusiva
-- Usuário sinaliza uma avaliação como abusiva/falsa; o admin resolve pela
-- fila de moderação (remover a avaliação denunciada ou descartar a denúncia).
-- Um mesmo usuário não pode denunciar a mesma avaliação mais de uma vez
-- (UNIQUE em id_avaliacao + id_usuario). Se a avaliação for excluída (por
-- este fluxo ou por delete_review.php), as denúncias associadas somem
-- junto (ON DELETE CASCADE) — não há por que manter denúncia órfã.

CREATE TABLE `denuncias` (
  `id_denuncia` int NOT NULL AUTO_INCREMENT,
  `id_avaliacao` int NOT NULL,
  `id_usuario` int NOT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `status` enum('pendente','descartada') NOT NULL DEFAULT 'pendente',
  `data_denuncia` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_denuncia`),
  UNIQUE KEY `denuncia_unica` (`id_avaliacao`, `id_usuario`),
  KEY `denuncias_ibfk_2` (`id_usuario`),
  CONSTRAINT `denuncias_ibfk_1` FOREIGN KEY (`id_avaliacao`) REFERENCES `avaliacoes` (`id_avaliacao`) ON DELETE CASCADE,
  CONSTRAINT `denuncias_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
