-- MecOn - Migração 011: geolocalização das oficinas
-- Permite buscar oficinas por distância real (não só por texto de
-- cidade/bairro). Coordenadas são opcionais — sem geocodificação
-- automática (exigiria uma API paga/externa fora do escopo atual), a
-- oficina ou o admin informam manualmente latitude/longitude (ex: abrindo
-- o endereço no Google Maps e copiando as coordenadas).

ALTER TABLE oficinas
    ADD COLUMN `latitude` decimal(10,7) NULL AFTER `endereco`,
    ADD COLUMN `longitude` decimal(10,7) NULL AFTER `latitude`;
