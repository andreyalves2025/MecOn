-- MecOn - Migração 004: resposta pública da oficina à avaliação
-- A oficina pode responder publicamente a uma avaliação recebida (como no
-- Google Maps/iFood). Uma avaliação tem no máximo uma resposta; respondê-la
-- de novo substitui o texto anterior (edição), e enviar resposta vazia
-- remove a resposta (ver backend/avaliacoes/responder_review.php).

ALTER TABLE avaliacoes
    ADD COLUMN `resposta_oficina` text NULL AFTER `comentario`,
    ADD COLUMN `data_resposta` timestamp NULL DEFAULT NULL AFTER `resposta_oficina`;
