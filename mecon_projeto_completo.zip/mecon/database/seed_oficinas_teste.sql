-- MecOn - 5 oficinas de teste (compatível com o DDL atual, 23 tabelas)
-- Senha de todas as oficinas: Teste@123  (hash bcrypt, $2y$10)
-- Execute no MySQL Workbench com o schema `mecon` selecionado.

-- 1) Serviços (INSERT IGNORE: se já existirem, nada muda)
INSERT IGNORE INTO servicos (nome, intervalo_recomendado_meses, intervalo_recomendado_km) VALUES
 ('Troca de óleo', 6, 10000),
 ('Alinhamento e balanceamento', 6, 10000),
 ('Revisão de freios', 12, 20000),
 ('Troca de bateria', 24, NULL),
 ('Revisão completa', 12, 15000),
 ('Suspensão', 12, 30000),
 ('Ar-condicionado', 12, NULL),
 ('Elétrica automotiva', 12, NULL);

-- 2) Oficinas
INSERT INTO oficinas
 (nome, email, senha_hash, cidade, bairro, endereco, latitude, longitude, telefone, descricao, verificada, verificada_em)
VALUES
 ('Auto Center Pinhais', 'autocenter.pinhais@example.com', '$2y$10$pgGrw/z5oomde51WM6hyhuLZY2lVUzfNIyGVsOjb4Fu5S9mpRnPPO',
  'Pinhais', 'Centro', 'Rua Teste Um, 100', -25.4443000, -49.1925000, '(41) 99000-0001',
  'Mecânica geral e revisão preventiva com atendimento por hora marcada.', 1, NOW()),
 ('Mecânica Emiliano', 'mecanica.emiliano@example.com', '$2y$10$pgGrw/z5oomde51WM6hyhuLZY2lVUzfNIyGVsOjb4Fu5S9mpRnPPO',
  'Pinhais', 'Emiliano Perneta', 'Av. Teste Dois, 250', -25.4310000, -49.1860000, '(41) 99000-0002',
  'Especializada em freios, suspensão e alinhamento.', 1, NOW()),
 ('Oficina do Portão', 'oficina.portao@example.com', '$2y$10$pgGrw/z5oomde51WM6hyhuLZY2lVUzfNIyGVsOjb4Fu5S9mpRnPPO',
  'Curitiba', 'Portão', 'Rua Teste Três, 330', -25.4770000, -49.2960000, '(41) 99000-0003',
  'Oficina familiar com foco em injeção eletrônica e parte elétrica.', 1, NOW()),
 ('Speed Car Boqueirão', 'speedcar.boqueirao@example.com', '$2y$10$pgGrw/z5oomde51WM6hyhuLZY2lVUzfNIyGVsOjb4Fu5S9mpRnPPO',
  'Curitiba', 'Boqueirão', 'Rua Teste Quatro, 410', -25.5050000, -49.2350000, '(41) 99000-0004',
  'Troca de óleo rápida, pneus e ar-condicionado.', 0, NULL),
 ('Garagem Água Verde', 'garagem.aguaverde@example.com', '$2y$10$pgGrw/z5oomde51WM6hyhuLZY2lVUzfNIyGVsOjb4Fu5S9mpRnPPO',
  'Curitiba', 'Água Verde', 'Av. Teste Cinco, 520', -25.4540000, -49.2810000, '(41) 99000-0005',
  'Revisões completas e manutenção de carros nacionais e importados.', 0, NULL);

-- 3) Serviços e preços de cada oficina
INSERT INTO oficina_servico (id_oficina, id_servico, preco)
SELECT o.id_oficina, s.id_servico, v.preco
FROM (
  SELECT 'autocenter.pinhais@example.com' AS e, 'Troca de óleo' AS n, 140.00 AS preco
  UNION ALL SELECT 'autocenter.pinhais@example.com', 'Alinhamento e balanceamento', 120.00
  UNION ALL SELECT 'autocenter.pinhais@example.com', 'Revisão completa', 480.00
  UNION ALL SELECT 'mecanica.emiliano@example.com', 'Revisão de freios', 220.00
  UNION ALL SELECT 'mecanica.emiliano@example.com', 'Suspensão', 350.00
  UNION ALL SELECT 'mecanica.emiliano@example.com', 'Alinhamento e balanceamento', 110.00
  UNION ALL SELECT 'oficina.portao@example.com', 'Elétrica automotiva', 180.00
  UNION ALL SELECT 'oficina.portao@example.com', 'Troca de bateria', 90.00
  UNION ALL SELECT 'oficina.portao@example.com', 'Troca de óleo', 130.00
  UNION ALL SELECT 'speedcar.boqueirao@example.com', 'Troca de óleo', 120.00
  UNION ALL SELECT 'speedcar.boqueirao@example.com', 'Ar-condicionado', 250.00
  UNION ALL SELECT 'speedcar.boqueirao@example.com', 'Alinhamento e balanceamento', 100.00
  UNION ALL SELECT 'garagem.aguaverde@example.com', 'Revisão completa', 520.00
  UNION ALL SELECT 'garagem.aguaverde@example.com', 'Revisão de freios', 240.00
  UNION ALL SELECT 'garagem.aguaverde@example.com', 'Troca de óleo', 160.00
) v
JOIN oficinas o ON o.email = v.e
JOIN servicos s ON s.nome = v.n;

-- Conferência
SELECT o.id_oficina, o.nome, o.bairro, o.verificada, COUNT(os.id_servico) AS servicos
FROM oficinas o LEFT JOIN oficina_servico os ON os.id_oficina = o.id_oficina
WHERE o.email LIKE '%@example.com'
GROUP BY o.id_oficina;

-- Para remover os dados de teste (oficina_servico sai por ON DELETE CASCADE):
-- DELETE FROM oficinas WHERE email LIKE '%@example.com';
