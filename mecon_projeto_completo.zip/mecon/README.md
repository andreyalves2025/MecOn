# MecOn

Plataforma web que conecta **motoristas** e **oficinas mecânicas** locais: o motorista busca e compara oficinas por **preço de cada serviço** e por **proximidade**, pede orçamento com fotos/vídeos, conversa com a oficina, agenda, acompanha a ordem de serviço e guarda o histórico de manutenção do veículo; a oficina ganha visibilidade, agenda e gestão digital.

Projeto interdisciplinar do IFPR – Campus Pinhais (Projeto III), apresentado no V WIPEX 2026.

> **Status: protótipo funcional (MVP) de demonstração.** Não é um produto pronto para produção: veja [Limitações](#limitações-conhecidas) e o checklist de [publicação](#antes-de-expor-na-internet).

## O que o sistema faz

| Perfil | Principais recursos |
|---|---|
| **Motorista** | busca por texto e filtros combinados (serviço, faixa de preço, avaliação, selo, proximidade por geolocalização); comparação de até 3 oficinas; recomendação; pedido de orçamento digital com anexos; chat; agendamento; veículos com controle de km; histórico de manutenção (valores, peças, mão de obra); lembretes por tempo e km; avaliações; favoritos; **exportar e excluir a própria conta (LGPD)** |
| **Oficina** | perfil e localização; **tabela de preços por serviço**; resposta a orçamentos; aceite/recusa/conclusão de agendamentos; ordem de serviço digital (etapas, itens, diagnóstico, desconto); mini-CRM; relatório financeiro; reputação; promoções; resposta pública às avaliações |
| **Administrador** | painel de métricas; verificação (selo) de oficinas; **desativação/reativação de oficinas**; moderação de denúncias; catálogo de serviços; log de auditoria |

### Diferenciais × onde estão no modelo de dados

| Diferencial citado no plano | Tabela / coluna | Endpoint principal |
|---|---|---|
| Preço exato por serviço | `oficina_servico.preco` (PK `id_oficina`+`id_servico`) | `oficinas/filter_oficinas.php`, `oficinas/get_oficina.php` |
| Geolocalização | `oficinas.latitude`, `oficinas.longitude` (fórmula de Haversine) | `oficinas/filter_oficinas.php` (proximidade), `oficinas/recomendar_oficinas.php` |
| Avaliação verificada | `avaliacoes.id_agendamento` (avaliação ligada a serviço concluído) | `avaliacoes/create_review.php` |
| Livro digital do veículo | `veiculos`, `historico_manutencoes`, `pecas_utilizadas` | `historico/*.php`, `historico/lembretes_manutencao.php` |
| Jornada completa | `pedidos_orcamento`, `orcamentos`, `agendamentos`, `ordens_servico`, `itens_os`, `conversas`, `mensagens` | `orcamentos/*`, `agendamentos/*`, `ordens_servico/*`, `chat/*` |

## Tecnologias
PHP (PDO), MySQL, HTML5, CSS3 e JavaScript puro (sem frameworks). Sessões PHP, senhas com `password_hash` (bcrypt), consultas parametrizadas.

## Estrutura
```
backend/      API em PHP (um arquivo por endpoint) + config/ (helpers)
frontend/     páginas HTML, css/, js/, img/
database/     schema.sql (schema final, 23 tabelas) e seeds de demonstração
migrations/   001–028: histórico incremental do schema (para bancos já existentes)
logs/         e-mails de desenvolvimento (bloqueado por .htaccess)
```

## Como executar (local)

**Requisitos:** Apache + PHP 7.4 ou superior (testado em 8.3) com `pdo_mysql`, `mbstring` e `fileinfo`; **MySQL 8.0.16 ou superior** (o schema usa `CHECK` e a collation `utf8mb4_0900_ai_ci`). WampServer, XAMPP ou equivalente servem.

1. Copie `backend/`, `frontend/` e `logs/` para `htdocs/mecon/` (ou `www/mecon/` no Wamp). **O nome da pasta precisa ser `mecon`**: o frontend chama a API em `/mecon/backend` (constante `MECON_API_BASE` em `frontend/js/auth.js`).
2. Crie o banco e importe o schema:
   ```sql
   CREATE DATABASE mecon CHARACTER SET utf8mb4;
   ```
   ```bash
   mysql -u root -p mecon < database/schema.sql
   mysql -u root -p mecon < database/seed_completo_mecon.sql   # dados de demonstração (opcional)
   ```
   O `schema.sql` já inclui todas as migrações: **não rode as duas coisas**. Em um banco antigo com dados, aplique `migrations/` em ordem (até a 028) e depois rode `php backend/tools/cifrar_placas.php`.
3. Configure o acesso ao banco em `backend/config/database.php` (`DB_PASS`) **ou** pelas variáveis de ambiente `MECON_DB_HOST`, `MECON_DB_PORT`, `MECON_DB_NAME`, `MECON_DB_USER`, `MECON_DB_PASS` (e `MECON_DEBUG=0` para ocultar detalhes de erro).
4. Abra `http://localhost/mecon/frontend/` (sempre pelo Apache, nunca por "Live Server": os cookies de sessão quebram entre origens).
5. Uploads de orçamento: no `php.ini`, `upload_max_filesize` ≥ 25M e `post_max_size` ≥ 30M.

### Contas de demonstração (senha de todas: `Teste@123`)
| Perfil | Login |
|---|---|
| Administrador | `admin@example.com` |
| Motoristas | `ana.souza@example.com`, `bruno.lima@example.com`, `carla.mendes@example.com` |
| Oficinas | `autocenter.pinhais@example.com`, `mecanica.emiliano@example.com`, `oficina.portao@example.com` (verificadas); `speedcar.boqueirao@example.com`, `garagem.aguaverde@example.com` (não verificadas) |

O seed é re-executável (apaga e recria só os registros `@example.com`) e usa datas relativas a `NOW()`. Sugestão de roteiro de demonstração: entrar como `oficina.portao@example.com` (OS em execução, agendamentos do dia) e como `bruno.lima@example.com`.

### E-mail
Com `EMAIL_MODO_DEV = true` (`backend/config/email.php`) nenhum e-mail real é enviado: o link de verificação aparece na resposta do cadastro e em `logs/`. **Nunca deixe isso ligado em produção.**

## Banco de dados
- `database/schema.sql`: 23 tabelas, ordem de criação validada (nenhuma FK aponta para tabela criada depois).
- **Histórico preservado (migração 025):** `historico_manutencoes`, `agendamentos` e `ordens_servico` apontam para a oficina com `ON DELETE RESTRICT`. O botão "Excluir" do administrador **desativa** a oficina (`oficinas.ativa = 0`): ela sai das buscas e do login, mas o histórico dos clientes continua. O histórico só é apagado quando o cliente exclui o veículo ou a conta (`ON DELETE CASCADE` a partir de `veiculos`/`usuarios`).

## LGPD (migração 026)
- Aceite dos **Termos de Uso** e da **Política de Privacidade** no cadastro (`usuarios.termos_aceitos_em`, `termos_versao`); páginas `frontend/pages/termos.html` e `privacidade.html`.
- Perfil → *Dados da conta*: **Baixar meus dados** (`usuarios/exportar_meus_dados.php`, JSON, sem hash de senha) e **Excluir minha conta** (`usuarios/excluir_minha_conta.php`, exige a senha; apaga em cascata veículos, histórico, pedidos, mensagens e os arquivos de anexo; agendamentos, OS e avaliações são preservados sem vínculo com o titular: a oficina vê "Cliente removido").
- A placa do veículo vinculada à conta é tratada como dado pessoal (migração 027):
  - **Cifrada em repouso** (AES-256-GCM, `backend/config/placa.php`) em `veiculos.placa` e `agendamentos.placa_snapshot`. Chave em `MECON_CHAVE_PLACA` (base64 de 32 bytes) ou `backend/storage/chave_placa.key` (gerada sozinha, fora do Git). **Guarde a chave separada do backup do banco.** Após atualizar um banco existente: `php backend/tools/cifrar_placas.php`. Após carregar o seed, rode o mesmo comando.
  - **Mascarada para a oficina** (`ABC****`) até haver agendamento aceito/concluído ou orçamento aprovado.
  - **Excluir a conta não apaga agendamentos nem ordens de serviço**: ficam para a oficina (`id_usuario`/`id_veiculo` = NULL via `ON DELETE SET NULL`, mensagem do cliente removida, nome exibido como "Cliente removido"; placa cifrada mantida).
- ⚠️ Os textos jurídicos são **modelos de partida**: preencha os campos `[entre colchetes]` (controlador, encarregado, foro) e submeta a revisão jurídica antes do lançamento comercial.

## Segurança implementada
Senhas bcrypt · consultas parametrizadas (PDO) · limite de tentativas de login · verificação de e-mail · anexos com tipo validado (finfo) e download autenticado · log de auditoria das ações do administrador · sessões separadas para usuário e oficina.

## Antes de expor na internet
1. Apagar `backend/diagnostico.php`.
2. `APP_DEBUG` = false (ou `MECON_DEBUG=0`).
3. Trocar as senhas das contas do seed e **não** carregar o seed em produção.
4. Configurar SMTP real e `EMAIL_MODO_DEV = false`.
5. Servir por HTTPS.
6. Preencher e revisar a Política de Privacidade e os Termos de Uso.

## Limitações conhecidas
- Sem testes automatizados; validação feita por testes manuais e de integração pontuais.
- Recuperação de senha por e-mail ainda não existe.
- A amostra do questionário de pesquisa (8 motoristas) é exploratória; não houve teste de usabilidade com usuários reais.
- Exclusão de conta do titular apaga também suas avaliações; oficinas (pessoas jurídicas) são desativadas, não excluídas.
- Contas de oficina não registram aceite dos termos (cadastradas pelo administrador).

## Documentação
`MANIFESTO.md` descreve o que cada rodada de funcionalidades adicionou e o que foi verificado.
