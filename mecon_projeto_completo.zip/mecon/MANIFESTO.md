# MecOn — Pacote completo do projeto

Projeto inteiro (código original + 2 rodadas de funcionalidades), pronto para
substituir a pasta do projeto no WampServer (`www/mecon/`).

## Como aplicar
1. **Banco novo (recomendado se os dados atuais são só de teste):** rode apenas
   `database/schema.sql` num banco `mecon` vazio (23 tabelas, já com as migrações até a 028; a ordem de criação
   foi validada — nenhuma FOREIGN KEY referencia tabela criada depois dela). As
   migrações já estão embutidas nele; **não rode as duas coisas**.
2. **Banco existente com dados:** rode `migrations/001_*.sql` até `028_*.sql` (depois `php backend/tools/cifrar_placas.php`),
   uma por vez, em ordem. (A 001 começa com um SELECT que detecta e-mails de
   oficina duplicados; se retornar linhas, resolva antes de seguir.)
3. Copie `backend/`, `frontend/` e `logs/` para dentro de `www/mecon/`.
4. Edite `backend/config/database.php` (senha do MySQL local em `DB_PASS`).

## Requisitos do ambiente (WampServer64)
- **MySQL 8.0.16 ou superior** — o schema usa a collation `utf8mb4_0900_ai_ci`
  e `CHECK` constraints (MariaDB e MySQL 5.7 NÃO servem). Confirme com
  `SELECT VERSION();`.
- **PHP 7.1 ou superior** (recomendado 7.4+/8.x), com as extensões `pdo_mysql`,
  `mbstring` e **`fileinfo`** (esta valida o tipo real dos anexos).
- **Uploads (orçamento digital):** confira no `php.ini` `file_uploads = On`,
  `upload_max_filesize` (≥ 25M para vídeos) e `post_max_size` (≥ 30M). Se os
  limites forem menores, o sistema recusa o envio com uma mensagem dizendo qual.
- Abra o sistema SEMPRE pela URL do Wamp (`http://localhost/mecon/frontend/...`),
  nunca pelo Live Server do VS Code (cookies de sessão quebram entre origens).
- A pasta pode ter qualquer nome? **Não:** os caminhos assumem `www/mecon/`
  (`MECON_API_BASE` em `frontend/js/auth.js` e os links de e-mail dev).
- E-mail: `EMAIL_MODO_DEV = true` em `backend/config/email.php` (sem SMTP real).

## Ajustes de compatibilidade já aplicados
- Fuso horário: `database.php` fixa `America/Sao_Paulo` no PHP **e** na sessão
  do MySQL (antes, PHP e MySQL podiam divergir por horas).
- `logs/.htaccess` bloqueia acesso direto ao log de e-mails de desenvolvimento.
- `backend/storage/anexos/.htaccess` bloqueia acesso direto às fotos/vídeos.
  Requer `AllowOverride` habilitado no Apache; sem isso, os arquivos continuam
  protegidos só pelo nome aleatório de 32 caracteres.

## Rodada 1 — funcionalidades 1 a 16 (migrações 001–013)
UNIQUE do e-mail da oficina · CRUD do catálogo de serviços · preço por serviço ·
paginação · resposta da oficina à avaliação · denúncia e fila de moderação ·
selo de oficina verificada · promoções · rate limiting no login · verificação de
e-mail · lembretes de manutenção · busca por proximidade · comparador ·
agendamento · dashboard do admin · log de auditoria.

## Rodada 2 — migrações 014–024
| Migração | Funcionalidade |
|---|---|
| 014 | Avaliação verificada (selo "serviço confirmado pelo MecOn") |
| 015 | Histórico de confiança da oficina (verificada há X meses, serviços concluídos) |
| 016 | Histórico de alterações detalhado (campo, valor anterior, valor novo) |
| 017 | Controle de quilometragem (veículo e histórico) |
| 018 | Histórico financeiro (valor total, peças, mão de obra) |
| 019 | Cadastro de peças utilizadas |
| 020 | Reputação da oficina (taxa de conclusão/aceite, tempo de resposta) |
| 021 | Lembretes inteligentes (tempo + quilometragem) |
| 022 | Chat entre cliente e oficina |
| 023 | Orçamento digital (pedido, orçamentos por oficina, anexos) |
| 024 | Ordem de serviço digital (etapas, itens, fechamento automático) |

Sem migração própria (só código): detecção de manutenção pendente (selo no
header e seção na home), ofertas personalizadas, mini-CRM da oficina,
relatórios financeiros da oficina e recomendação personalizada de oficinas.
Serviços adicionais (elétrica, pneus, funilaria...) já são atendidos pelo CRUD
do catálogo de serviços.

## Rodada 3 — correções pós-apresentação (migrações 025–028)
- **025 — histórico preservado:** `historico_manutencoes`, `agendamentos` e
  `ordens_servico` passam de `ON DELETE CASCADE` para `RESTRICT` em relação à
  oficina (e ao serviço). Oficinas ganham exclusão lógica (`ativa`,
  `desativada_em`): `delete_oficina.php` agora desativa; novo
  `reativar_oficina.php`. Buscas, recomendações, promoções, login e novos
  pedidos ignoram oficinas inativas.
- **026 — LGPD:** aceite de Termos/Política no cadastro, páginas
  `termos.html` e `privacidade.html`, `auth/aceitar_termos.php`,
  `usuarios/exportar_meus_dados.php` e `usuarios/excluir_minha_conta.php`.
- **027 — placa e retenção:** placa cifrada (AES-256-GCM, `config/placa.php`) e
  mascarada para a oficina até o agendamento ser aceito; `agendamentos.placa_snapshot`;
  `agendamentos.id_usuario/id_veiculo` passam a `ON DELETE SET NULL`: excluir a conta
  mantém agendamentos e OS para a oficina ("Cliente removido"). Novo
  `tools/cifrar_placas.php`.
- **028 — avaliações anônimas:** `avaliacoes.id_usuario` passa a `ON DELETE SET NULL`;
  a avaliação (nota, comentário, resposta) permanece como "Cliente removido" e continua
  na reputação da oficina.
- `README.md` na raiz, `database.php` com variáveis de ambiente opcionais e o
  seed com mais avaliações, chats e ordens de serviço.

## Novas pastas do backend (rodada 2)
`chat/` · `orcamentos/` · `ordens_servico/` · `storage/anexos/` e os helpers
`config/` `anexos.php`, `chat.php`, `crm.php`, `lembretes.php`, `os.php`,
`pecas.php`, `reputacao.php`, `valores.php`.
Novas páginas: `ordem-servico.html` (visualização/impressão). Novo script
compartilhado: `js/chat.js`.

## Ficou para depois (decisão sua)
Diagnóstico orientativo por sintoma · agenda inteligente com capacidade ·
programa de fidelidade · cupons · indicação · "tipo de veículo" nos lembretes ·
recuperação de senha por e-mail real · galeria de fotos da oficina · testes
automatizados · documentação OpenAPI.

## O que foi (e o que NÃO foi) verificado
Verificado (rodada 3): sintaxe de todo o PHP (`php -l`, PHP 8.3) e JS
(`node --check`); schema novo e schema antigo + migrações 025/026 geram a
mesma estrutura; o seed roda duas vezes seguidas; os endpoints novos e
alterados foram executados via HTTP contra um banco real (cadastro com e sem
aceite, exportação, exclusão de conta com remoção de anexos, desativação,
reativação e login de oficina, `RESTRICT` recusando a exclusão física).
**Não** verificado: o banco usado nos testes foi **MariaDB 10.11** (com a
collation trocada por `utf8mb4_general_ci`), não MySQL 8 — rode o schema em um
MySQL 8.0.16+ real; nenhuma tela foi aberta em navegador.
