<?php
/**
 * MecOn - diagnóstico de ambiente (APENAS DESENVOLVIMENTO).
 * Abra em: http://localhost/mecon/backend/diagnostico.php
 * APAGUE este arquivo antes de publicar o sistema.
 */
require_once __DIR__ . '/config/database.php';
header('Content-Type: text/html; charset=utf-8');
$linhas = [];
function ok($t)   { global $linhas; $linhas[] = ['ok', $t]; }
function erro($t) { global $linhas; $linhas[] = ['erro', $t]; }
function aviso($t){ global $linhas; $linhas[] = ['aviso', $t]; }
function info($t) { global $linhas; $linhas[] = ['info', $t]; }

// 1) PHP e extensões
info('PHP ' . PHP_VERSION);
foreach (['pdo_mysql', 'mbstring', 'fileinfo', 'json'] as $ext) {
    extension_loaded($ext) ? ok("Extensão $ext carregada") : erro("Extensão $ext NÃO carregada (Wamp: ícone > PHP > Extensões PHP)");
}
// 2) Caminho da pasta
$uri = $_SERVER['REQUEST_URI'] ?? '';
strpos($uri, '/mecon/backend/') === 0
    ? ok("Pasta correta: $uri")
    : erro("Esta URL é $uri. O projeto precisa estar em www/mecon/ (o front-end chama /mecon/backend/...).");

// 3) Conexão
$pdo = null;
try {
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    ok('Conectou em ' . DB_HOST . ':' . DB_PORT . ' no banco "' . DB_NAME . '" com o usuário "' . DB_USER . '"');
} catch (PDOException $e) {
    $m = $e->getMessage();
    erro('Falha na conexão: ' . $m);
    if (stripos($m, 'Access denied') !== false) aviso('Senha/usuário errados: ajuste DB_USER/DB_PASS em backend/config/database.php.');
    if (stripos($m, 'Unknown database') !== false) aviso('O banco "' . DB_NAME . '" não existe NESTE servidor MySQL. Se existe no Workbench, ele está em outro servidor/porta (veja abaixo).');
    if (stripos($m, 'refused') !== false || stripos($m, '2002') !== false) aviso('Nada respondendo em ' . DB_HOST . ':' . DB_PORT . '. Confira se o MySQL do Wamp está verde e qual porta ele usa.');
}
if ($pdo) {
    $r = $pdo->query('SELECT VERSION() v, @@port p, @@hostname h, @@version_comment c, DATABASE() d, @@sql_mode m')->fetch();
    info('Servidor: ' . $r['v'] . ' (' . $r['c'] . ') | porta ' . $r['p'] . ' | host ' . $r['h'] . ' | banco ' . $r['d']);
    info('Compare a PORTA e o HOST acima com a conexão do MySQL Workbench: devem ser o mesmo servidor.');
    if (stripos($r['v'], 'mariadb') !== false) erro('Servidor é MariaDB: o schema exige MySQL 8.0.16+.');
    elseif (version_compare(preg_replace('/[^0-9.].*/', '', $r['v']), '8.0.16', '<')) erro('MySQL abaixo de 8.0.16: o schema (CHECK + collation 0900) exige 8.0.16+.');
    else ok('Versão do MySQL adequada');

    // 4) Tabelas
    $esperadas = ['usuarios','oficinas','servicos','oficina_servico','promocoes','avaliacoes','denuncias','favoritos','veiculos','historico_manutencoes','pecas_utilizadas','pedidos_orcamento','orcamentos','anexos_pedido','agendamentos','conversas','mensagens','ordens_servico','itens_os','tentativas_login','tokens_verificacao_email','log_auditoria','log_auditoria_detalhe'];
    $existentes = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    $faltam = array_values(array_diff($esperadas, $existentes));
    $faltam ? erro('Tabelas ausentes: ' . implode(', ', $faltam)) : ok('As 23 tabelas existem');

    // 5) Colunas que o código usa
    $colunas = ['oficinas' => ['latitude','longitude','verificada','verificada_em'], 'oficina_servico' => ['preco'], 'servicos' => ['ativo','intervalo_recomendado_meses','intervalo_recomendado_km']];
    foreach ($colunas as $tab => $cols) {
        if (!in_array($tab, $existentes, true)) continue;
        $tem = $pdo->query("SHOW COLUMNS FROM `$tab`")->fetchAll(PDO::FETCH_COLUMN);
        $f = array_diff($cols, $tem);
        $f ? erro("Tabela $tab sem as colunas: " . implode(', ', $f) . ' (banco desatualizado: rode o schema.sql novo ou as migrações)') : ok("Colunas de $tab OK");
        if ($tab === 'oficinas' && in_array('preco_medio', $tem, true)) aviso('oficinas ainda tem a coluna antiga preco_medio (NOT NULL): inserts sem ela vão falhar. Rode a migração que a remove.');
    }
    // 6) Dados e consulta real
    foreach (['oficinas', 'servicos', 'oficina_servico'] as $t) {
        if (in_array($t, $existentes, true)) {
            $n = (int) $pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
            $n > 0 ? ok("$t: $n registro(s)") : aviso("$t está VAZIA neste servidor/banco");
        }
    }
    try {
        $rows = $pdo->query('SELECT o.id_oficina, o.nome, ROUND(AVG(a.nota),1) media FROM oficinas o LEFT JOIN avaliacoes a ON a.id_oficina=o.id_oficina GROUP BY o.id_oficina ORDER BY o.nome LIMIT 5')->fetchAll();
        ok('Consulta de listagem executou: ' . count($rows) . ' linha(s) de amostra');
        foreach ($rows as $x) {
            info('· #' . $x['id_oficina'] . ' ' . $x['nome']);
            if (strpos($x['nome'], 'Ã') !== false) aviso('Acentos corrompidos ("Ã") em "' . $x['nome'] . '": os dados foram importados com charset errado. Reimporte com utf8mb4.');
        }
    } catch (PDOException $e) { erro('Consulta de listagem FALHOU: ' . $e->getMessage()); }
}
$cores = ['ok' => '#1b7f3b', 'erro' => '#b00020', 'aviso' => '#a15c00', 'info' => '#333'];
$icone = ['ok' => '✔', 'erro' => '✖', 'aviso' => '⚠', 'info' => 'ℹ'];
echo '<!doctype html><meta charset="utf-8"><title>Diagnóstico MecOn</title><body style="font-family:Arial;max-width:900px;margin:24px auto;line-height:1.6"><h2>Diagnóstico MecOn</h2>';
foreach ($linhas as [$tipo, $txt]) echo '<div style="color:' . $cores[$tipo] . '">' . $icone[$tipo] . ' ' . htmlspecialchars($txt) . '</div>';
echo '<p style="color:#888">Apague backend/diagnostico.php antes de publicar.</p>';
